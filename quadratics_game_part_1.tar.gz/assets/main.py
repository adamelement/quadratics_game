"""FROG QUADRATICS - single-file, configurable Pygame prototype.

Run locally: pip install pygame; python main.py
Browser: python -m pygbag .
Artwork is OPTIONAL. Put transparent PNGs in assets/ with names specified below.
All scene/level/question content is editable near the top of this file.

Controls: mouse to edit boxes and buttons; TAB changes box; ENTER plots;
J launches; G toggles grid; R restarts round; ESC opens/closes menu;
SPACE skips a cutscene. The plot must pass through the frog's current
position; this is checked on ENTER. Quadratic coordinates are world units.
"""
import asyncio
import math
import os
import random
from dataclasses import dataclass

import pygame
import sys

# =========================== EDITABLE CONFIGURATION ==========================
W, H = 1100, 660
FPS = 60
SIMULATED_GRAVITY = 25.0  # World units/s^2, downward for jumps and upward for controlled dives.
GROUND_Y = 515
SCALE = H // 20  # 33 pixels per unit; visible y range -10 to +10.
ORIGIN_X, ORIGIN_Y = W // 2, H // 2  # (0, 0) centered in the graph area
START_X = 105
EXIT_X = 1015
ASSET_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'assets')
INK = (27, 48, 68)
BLUE = (34, 113, 183)
GREEN = (43, 147, 101)
RED = (192, 66, 64)

# Level artwork uses screen pixels; the graph has (0,0) at ORIGIN_X,ORIGIN_Y.
# ALL mathematical trajectories use world units and the SAME x/y SCALE.
# Obstacles use their bottom-left (x, bottom) pixel position and pixel size.
# If a named image is absent, a colored placeholder is drawn instead.
LEVELS = {
    'practice': dict(title='Free Practice', theme='practice', mode='both',
        background=None, obstacles=[], intro='Plot a quadratic and practice jumping. R resets Frogo.'),
    'park_1': dict(title='Park: First Steps', theme='park', mode='negative',
        background='park_background.png', obstacles=[
            dict(name='fallen_log', image='fallen_log.png', x=375, bottom=GROUND_Y, w=180, h=76, collision='rect', landable=True),
            dict(name='thorn_bush', image='thorn_bush.png', x=755, bottom=GROUND_Y, w=180, h=106, collision='mask', landable=False)],
        intro='Enter a negative a-value to jump OVER obstacles.'),
    'park_2': dict(title='Park: Playground', theme='park', mode='negative',
        background='tire_swing_background.png', obstacles=[],
        tire_gate=dict(x=742, top=205, bottom=450),
        intro='Choose a quadratic that takes Frogo through the tire.'),
    'city_1': dict(title='City: Escape Route', theme='city', mode='negative',
        background='city_street.png', obstacles=[
            dict(name='crate', image='crate.png', x=490, bottom=GROUND_Y, w=110, h=88, collision='rect', landable=False)],
        intro='Find a path through the city.'),
    'traffic': dict(title='Traffic: Cross Safely', theme='city', mode='negative',
        background='traffic_road.png', obstacles=[
            dict(name='car_left', image='car_blue.png', x=450, bottom=GROUND_Y, w=145, h=65,
                 collision='mask', landable=False, speed=-48, wrap=True, vehicle=True),
            dict(name='car_right', image='car_red.png', x=785, bottom=GROUND_Y, w=145, h=65,
                 collision='mask', landable=False, speed=38, wrap=True, vehicle=True)],
        intro='Two-way traffic! Jump over the cars. Timing matters.'),
    'lake_1': dict(title='Lake: Dive Under', theme='water', mode='positive',
        background='lake_background.png', obstacles=[
            dict(name='floating_log', image='floating_log.png', x=485, bottom=GROUND_Y+10, w=150, h=60,
                 collision='mask', landable=False)],
        intro='Enter a positive a-value to dive UNDER obstacles.'),
    'forest_1': dict(title='Forest: Almost Home', theme='forest', mode='both',
        background='forest_background.png', obstacles=[
            dict(name='rock', image='rock.png', x=520, bottom=GROUND_Y, w=125, h=92, collision='mask', landable=False)],
        intro='You may now use either positive or negative quadratics.'),
}

# Each entry is a playable level, a story cutscene, or the special box challenge.
# Add, delete or reorder entries here without changing the main game loop.
PART_ONE_ONLY = True  # Set False to restore the rest of the adventure.
GAME_SEQUENCE = [
    dict(type='scene', id='tornado_intro'),
    dict(type='instructions'),
    dict(type='level', id='park_1'),
    dict(type='level', id='park_2'),
    dict(type='scene', id='child_capture'),
    dict(type='box'),
    dict(type='level', id='city_1'),
    dict(type='level', id='traffic'),
    dict(type='scene', id='truck_ride'),
    dict(type='level', id='lake_1'),
    dict(type='scene', id='windsurfer'),
    dict(type='level', id='forest_1'),
    dict(type='scene', id='homecoming'),
    dict(type='ending'),
]

# Preserve all Part 2 entries above; disable them for the classroom release.
if PART_ONE_ONLY:
    GAME_SEQUENCE = GAME_SEQUENCE[:6] + [dict(type='level', id='practice')]

# Story scenes are timelines. Each beat uses a background and named sprites.
# Motion, rotation and alpha are controlled by the reusable scene renderer.
# More elaborate scenes can later be registered as dedicated Python functions.
SCENES = {
 'tornado_intro': dict(title='A Stormy Beginning', skippable=True, duration=17.5),
 'child_capture': dict(title='An Unexpected Visitor', skippable=True, beats=[
     dict(seconds=6.55, capture=True, caption='A child spotted Frogo!')]),
 'truck_ride': dict(title='A Surprise Ride', skippable=True, beats=[
     dict(seconds=2.2, background='traffic_road.png', caption='A truck pulled up beside Frogo!', frog=(680, 430), actor='delivery_truck.png', actor_at=(1100, 380), actor_to=(600, 380)),
     dict(seconds=3.5, background='truck_interior.png', caption='Frogo enjoyed the ride with a cool driver!', frog=(700, 320), actor='driver_sunglasses.png', actor_at=(320, 290)),
     dict(seconds=1.7, background='lake_background.png', caption='A new adventure was waiting...')]),
 'windsurfer': dict(title='A Friendly Greeting', skippable=True, beats=[
     dict(seconds=3.6, background='lake_background.png', caption='"Great job, Frogo!" called the windsurfer.', frog=(730, 455), actor='windsurfer.png', actor_at=(340, 360))]),
 'homecoming': dict(title='Home at Last', skippable=True, beats=[
     dict(seconds=2.5, background='forest_background.png', caption='Frogo recognized the path home...', frog=(250, 435), frog_to=(690, 435)),
     dict(seconds=3.0, background='home_pond.png', caption='At last, Frogo was home!', frog=(190, 430), frog_to=(600, 430))]),
}

# Add your own questions here. Answers can be numeric or multiple-choice.
QUESTIONS = [
 dict(prompt='For y = -2(x - 3)^2 + 5, what is h?', answer='3', hint='Vertex form is y = a(x - h)^2 + k.'),
 dict(prompt='For y = 0.5(x + 4)^2 - 1, what is k?', answer='-1', hint='k is the vertical coordinate of the vertex.'),
 dict(prompt='Does y = -3(x - 2)^2 + 6 open up or down?', answer='down', hint='Look at the sign of a.'),
 dict(prompt='What is the x-coordinate of the vertex of y = (x - 7)^2 + 2?', answer='7', hint='The vertex is (h, k).'),
 dict(prompt='What is the y-coordinate of the vertex of y = -(x + 1)^2 + 8?', answer='8', hint='The constant outside the square is k.'),
 dict(prompt='For y = 2(x - 3)^2 + 4, what is a?', answer='2', hint='a multiplies the squared bracket.'),
 dict(prompt='Is y = -0.25(x - 2)^2 + 1 wider or narrower than y = -2(x - 2)^2 + 1?', answer='wider', hint='Smaller absolute a means wider.'),
 dict(prompt='What is y when x = 4 for y = -(x - 2)^2 + 5?', answer='1', hint='Substitute x = 4 and evaluate the squared bracket first.'),
 dict(prompt='What is the axis of symmetry of y = (x - 6)^2 + 2? Enter x=...', answer='x=6', hint='The axis passes through the vertex.'),
 dict(prompt='For y = -2(x - 1)^2 + 3, what is y when x = 1?', answer='3', hint='The squared part becomes zero.'),
]
BOX_QUESTION_COUNT = 10  # number selected per attempt; repeats if bank is smaller
BOX_ESCAPE_CHANCES = {10: 1.0, 9: .5, 8: .3, 7: .2}  # other scores: 0
BOX_MIN_SCORE_TO_TRY = 6
BEDROOM_POSES = (("crouch", .85), ("brace", .30), ("push", .55), ("brace", .20))
BEDROOM_CYCLE = sum(t for _, t in BEDROOM_POSES)
BEDROOM_ATTEMPTS = 3
ESCAPE_POSES = (("lift", .8), ("climb", .9), ("free", 1.2))
ESCAPE_DURATION = sum(t for _, t in ESCAPE_POSES)


def bedroom_pose(elapsed, poses, loop=False):
    if loop:
        elapsed %= sum(t for _, t in poses)
    for pose, hold in poses:
        if elapsed < hold:
            return pose
        elapsed -= hold
    return poses[-1][0]


# ======================= PURE MATHEMATICAL GEOMETRY ========================
def quadratic_y(a, h, k, x):
    return a * (x - h)**2 + k


def horizontal_velocity(a, gravity=SIMULATED_GRAVITY):
    """Constant horizontal speed for a parabola with acceleration |gravity|.

    With x(t)=x0+vx*t and y(t)=a*(x(t)-h)^2+k,
    the vertical acceleration is 2*a*vx**2. For an ordinary jump
    this equals -gravity; for a controlled dive it equals +gravity.
    """
    if not math.isfinite(a) or abs(a) < 1e-9 or gravity <= 0:
        raise ValueError('Nonzero finite curvature and positive gravity required')
    return math.sqrt(gravity / (2.0 * abs(a)))


def right_intersection(a, h, k, y):
    """Rightmost intersection with a horizontal surface, or None."""
    if abs(a) < 1e-12:
        return None
    square = (y-k)/a
    if square < -1e-9:
        return None
    return h + math.sqrt(max(0.0, square))


def screen_to_world(px, py, origin_x=ORIGIN_X, origin_y=ORIGIN_Y, scale=SCALE):
    return ((px-origin_x)/scale, (origin_y-py)/scale)


def world_to_screen(x, y, origin_x=ORIGIN_X, origin_y=ORIGIN_Y, scale=SCALE):
    return (origin_x+x*scale, origin_y-y*scale)

# ================================ GAME ENGINE ================================
pygame.init()
pygame.display.set_caption('Frog Quadratics - Editable Prototype')
screen = pygame.display.set_mode((W, H), 0 if sys.platform == 'emscripten' else pygame.RESIZABLE)
clock = pygame.time.Clock()
FONT = pygame.font.SysFont('arial', 22)
SMALL = pygame.font.SysFont('arial', 17)
INPUT_FONT = pygame.font.SysFont('arial', 15)
BIG = pygame.font.SysFont('arial', 40, bold=True)
MED = pygame.font.SysFont('arial', 28, bold=True)


def txt(surface, message, x, y, font=FONT, color=INK, center=False):
    image = font.render(str(message), True, color)
    surface.blit(image, image.get_rect(center=(x, y)) if center else (x, y))


def scene_text(surface, message, x, y, font=FONT):
    # White lettering with a narrow dark outline, no caption panel.
    image = font.render(str(message), True, (255,255,255))
    shadow = font.render(str(message), True, (15,22,30))
    rect = image.get_rect(center=(x,y))
    for dx, dy in ((-2,0),(2,0),(0,-2),(0,2),(-1,-1),(1,1),(-1,1),(1,-1)):
        surface.blit(shadow, rect.move(dx,dy))
    surface.blit(image, rect)


def tire_crossing(gate, x0, y0, x1, y1):
    # Perspective projection: the visible opening is a portal, not a wall.
    # Use a stable feet anchor, not the changing rotated sprite rectangle.
    if not x0 < gate['x'] <= x1:
        return None
    t = (gate['x']-x0)/(x1-x0)
    feet = y0 + t*(y1-y0)
    return gate['top'] <= feet-30 and feet <= gate['bottom']


def rounded(surface, rect, color, radius=12, outline=None):
    pygame.draw.rect(surface, color, rect, border_radius=radius)
    if outline:
        pygame.draw.rect(surface, outline, rect, 2, border_radius=radius)


def button(surface, rect, label, enabled=True):
    rounded(surface, rect, BLUE if enabled else (150, 164, 172), 10)
    txt(surface, label, rect.centerx, rect.centery, SMALL, (255, 255, 255), True)


# =========================== TORNADO INTRO ===================================
INTRO_HOPS = 5.0
INTRO_APPROACH = 7.0
TORNADO_APPROACH_TIME = INTRO_APPROACH
INTRO_SWIRL = 3.0
INTRO_LAND = 2.5
INTRO_HOP_POINTS = ((350, 625), (555, 625), (785, 642))


def tornado_approach(seconds):
    p = max(0.0, min(1.0, seconds / TORNADO_APPROACH_TIME))
    return p * p * (3.0 - 2.0 * p)


def tornado_position(seconds):
    depth = tornado_approach(seconds)
    drift = math.sin(math.tau * seconds / 5.8)
    return 884 - 81 * depth + (12 + 22 * depth) * drift, 326 + 295 * depth


class RotatingFunnel:
    """Pre-rendered rotation, avoiding NumPy in the browser."""
    def __init__(self, sprite):
        self.size = sprite.get_size()
        self.frames = [sprite]
        path = os.path.join(ASSET_DIR, 'tornado_rotation.png')
        if os.path.isfile(path):
            sheet = pygame.image.load(path).convert_alpha()
            w, h = sheet.get_width() // 8, sheet.get_height() // 6
            self.frames = [sheet.subsurface((i % 8 * w, i // 8 * h, w, h))
                           for i in range(48)]
            self.size = (w, h)

    def frame(self, seconds):
        return self.frames[int(seconds * 0.68 * len(self.frames)) % len(self.frames)]


class TornadoIntro:
    def __init__(self):
        self.background = pygame.transform.smoothscale(pygame.image.load(os.path.join(ASSET_DIR, 'forest_pond.png')).convert(), (W, H))
        original = pygame.image.load(os.path.join(ASSET_DIR, 'tornado.png')).convert_alpha()
        height = 320
        width = max(1, round(original.get_width() * height / original.get_height()))
        self.funnel = RotatingFunnel(pygame.transform.smoothscale(original, (width, height)))
        self.water, self.storm, self.spray = [pygame.Surface((W, H), pygame.SRCALPHA) for _ in range(3)]
        self.blackout = pygame.Surface((W, H))
        self.blackout.fill((0, 0, 0))
        rng = random.Random(8)
        self.droplets = [(rng.random(), rng.uniform(-1, 1), rng.uniform(0.5, 1.0)) for _ in range(32)]

    def draw_funnel(self, sprite, x, y, seconds, depth):
        width, height = sprite.get_size()
        crown_rows = round(height * 0.34)
        crown_height = round(height * (0.34 + 0.18 * depth))
        crown = sprite.subsurface((0, 0, width, crown_rows))
        stem = sprite.subsurface((0, crown_rows, width, height - crown_rows))
        parts = (pygame.transform.smoothscale(crown, (width, crown_height)),
                 pygame.transform.smoothscale(stem, (width, height - crown_height)))
        top = round(y - height)
        left = x - width * 0.496
        row_offset = 0
        for part in parts:
            for row in range(0, part.get_height(), 4):
                fraction = (row_offset + row) / height
                sway = (8 + 20 * depth) * math.sin(math.tau * (0.39 * seconds - fraction))
                sway *= math.sin(math.tau * fraction / 2) ** 2
                band_height = min(4, part.get_height() - row)
                band = part.subsurface((0, row, width, band_height))
                crown_weight = max(0.0, 1.0 - fraction / 0.52) ** 2
                band_width = round(width * (1.0 + 0.20 * crown_weight))
                if band_width > width:
                    band = pygame.transform.smoothscale(band, (band_width, band_height))
                band_left = left + sway - 0.496 * (band_width - width)
                self.storm.blit(band, (round(band_left), top + row_offset + row))
            row_offset += part.get_height()

    def draw_water(self, seconds):
        current_ring = int(seconds / 0.23)
        for ring in range(max(0, current_ring - 7), current_ring + 1):
            born = ring * 0.23
            age = seconds - born
            if born < 0.85 or age >= 1.55:
                continue
            x, y = tornado_position(born)
            radius = (9 + 37 * age) * y / 490
            alpha = round(155 * (1 - age / 1.55))
            bounds = pygame.Rect(round(x - radius), round(y - radius * 0.23), round(radius * 2), max(3, round(radius * 0.46)))
            pygame.draw.ellipse(self.water, (185, 224, 216, alpha), bounds, 1)

    def draw_spray(self, x, y, height, seconds):
        for index, (phase, spread, lift) in enumerate(self.droplets):
            age = (seconds * (0.9 + lift * 0.6) + phase) % 1.0
            angle = math.tau * (phase + 1.35 * seconds)
            distance = height * (0.017 + 0.10 * age)
            px = x + (0.72 * math.cos(angle) + 0.28 * spread) * distance
            py = y + 0.20 * math.sin(angle) * distance
            py -= height * 0.18 * lift * age * (1 - age)
            alpha = round(180 * math.sin(age * math.tau / 2))
            pygame.draw.circle(self.spray, (211, 233, 221, alpha), (round(px), round(py)), 2 if height > 330 and index % 3 == 0 else 1)

    def draw_approach(self, surface, elapsed):
        x, y = tornado_position(elapsed)
        depth = tornado_approach(elapsed)
        cloud_top = 105 - 255 * depth ** 0.78
        height = round(y - cloud_top)
        visibility = min(1.0, elapsed / 1.15)
        surface.blit(self.background, (0, 0))
        for layer in (self.water, self.storm, self.spray):
            layer.fill((0, 0, 0, 0))
            layer.set_alpha(round(255 * visibility))
        self.draw_water(elapsed)
        width = max(1, round(self.funnel.size[0] * height / self.funnel.size[1] * (0.83 + 0.49 * depth)))
        sprite = pygame.transform.smoothscale(self.funnel.frame(elapsed), (width, height))
        self.draw_funnel(sprite, x, y, elapsed, depth)
        if elapsed >= 0.85:
            self.draw_spray(x, y, height, elapsed)
        for layer in (self.water, self.storm, self.spray):
            surface.blit(layer, (0, 0))
    def draw(self, surface, elapsed):
        # Coordinates are feet positions in the 1100 x 660 logical canvas.
        def grounded(pose, x, y):
            sprite = frog_base(pose, 1.35)
            surface.blit(sprite, sprite.get_rect(midbottom=(round(x), round(y))))

        def caption(message):
            scene_text(surface, message, W//2, 54)

        if elapsed < INTRO_HOPS:
            surface.blit(self.background, (0, 0))
            # Two ballistic hops, each with preparation and landing frames.
            hop = min(1, int(elapsed / 2.5))
            t = elapsed - hop * 2.5
            x0, y0 = INTRO_HOP_POINTS[hop]
            x1, y1 = INTRO_HOP_POINTS[hop+1]
            if t < 0.33:
                grounded(f'frame_{1+min(2,int(t/0.11))}', x0, y0)
            elif t < 0.47:
                grounded(f'frame_{4+min(1,int((t-0.33)/0.07))}', x0, y0)
            elif t < 1.67:
                u = (t-0.47)/1.2
                x = x0 + (x1-x0)*u
                y = y0 + (y1-y0)*u - 4*135*u*(1-u)
                angle = math.degrees(math.atan2(540*(1-2*u)-(y1-y0), x1-x0))
                frog_sprite(surface, x, y-22, angle, 'frame_6', 1.35)
            else:
                frame = min(10, 7+int((t-1.67)/0.08))
                grounded(f'frame_{frame}', x1, y1)
            caption('Frogo was enjoying a peaceful day, hopping around his home.')
        elif elapsed < INTRO_HOPS + INTRO_APPROACH:
            t = elapsed - INTRO_HOPS
            self.draw_approach(surface, t)
            grounded('rest', *INTRO_HOP_POINTS[-1])
            caption('But Frogo was unaware of the approaching tornado...')
        elif elapsed < INTRO_HOPS + INTRO_APPROACH + INTRO_SWIRL:
            t = elapsed - INTRO_HOPS - INTRO_APPROACH
            u = t / INTRO_SWIRL
            # Continue the same animated pond and funnel without a scene cut.
            storm_time = INTRO_APPROACH + t
            self.draw_approach(surface, storm_time)
            cx, cy = tornado_position(storm_time)
            start_x, start_y = INTRO_HOP_POINTS[-1]
            theta = math.tau * (1.2*t + 0.22*t*t)
            pull = min(1.0, t / 0.45)
            pull = pull * pull * (3 - 2 * pull)
            radius = 18 + 125*u
            x = (1-pull)*start_x + pull*(cx + radius*math.sin(theta))
            y = (1-pull)*(start_y-22) + pull*(cy-22-420*u + 0.22*radius*math.cos(theta))
            frog_sprite(surface, x, y, -720*t, 'frame_6', 1.35)
            caption('Before he could escape, Frogo was swept into the powerful tornado!')
        else:
            t = elapsed - INTRO_HOPS - INTRO_APPROACH - INTRO_SWIRL
            name = 'intro_after_storm.png'
            if not os.path.isfile(os.path.join(ASSET_DIR, name)):
                name = 'park_background.png'
            background(surface, name)
            # Accelerating fall, then absorb the impact and recover.
            fall = 1.15
            if t < fall:
                u = t/fall
                frog_sprite(surface, 240-135*u, -40+535*u*u, -540*u, 'frame_6', 1.35)
            else:
                frame = min(10, 7+int((t-fall)/0.08))
                grounded(f'frame_{frame}', 105, GROUND_Y)
            caption('When the storm finally passed, Frogo found himself far from home.')


class Images:
    def __init__(self):
        self.cache = {}
        self.mask_cache = {}
        self.rot_cache = {}
        self.frog_bases = {}
        self.frog_rotations = {}
        self.background_cache = {}

    def load(self, filename, size):
        key = (filename, tuple(map(int, size)))
        if key not in self.cache:
            path = os.path.join(ASSET_DIR, filename)
            if os.path.isfile(path):
                try:
                    source = pygame.image.load(path).convert_alpha()
                    self.cache[key] = pygame.transform.smoothscale(source, key[1])
                except pygame.error:
                    self.cache[key] = None
            else:
                self.cache[key] = None
        return self.cache[key]

    def rotated(self, filename, size, degrees):
        # Rotation is quantized/cached, never scaled or rotated repeatedly each frame.
        deg = int(round(degrees / 5) * 5) % 360
        key = (filename, tuple(map(int, size)), deg)
        if key not in self.rot_cache:
            src = self.load(filename, size)
            self.rot_cache[key] = pygame.transform.rotate(src, deg) if src else None
        return self.rot_cache[key]

    def mask(self, filename, size):
        key = (filename, tuple(map(int, size)))
        if key not in self.mask_cache:
            src = self.load(filename, size)
            self.mask_cache[key] = pygame.mask.from_surface(src) if src else None
        return self.mask_cache[key]

images = Images()


def _paint_background(surface, filename, theme='park'):
    image = images.load(filename, (W, H))
    if image:
        surface.blit(image, (0, 0))
        return
    sky = {'park': (191, 225, 240), 'city': (204, 219, 235),
           'water': (163, 215, 239), 'forest': (192, 229, 199)}.get(theme, (194, 225, 236))
    surface.fill(sky)
    if theme == 'city':
        for i in range(0, W, 135):
            pygame.draw.rect(surface, (154, 172, 187), (i + 15, 170 + (i % 3)*30, 100, 350))
            for j in range(3):
                pygame.draw.rect(surface, (241, 236, 169), (i + 38 + j*22, 245, 12, 18))
    else:
        for i in range(60, W, 170):
            pygame.draw.rect(surface, (111, 94, 66), (i, 325, 22, 195))
            pygame.draw.circle(surface, (70, 157, 98), (i + 10, 325), 68)
    if theme == 'water':
        pygame.draw.rect(surface, (71, 165, 207), (0, GROUND_Y, W, H-GROUND_Y))
        pygame.draw.line(surface, (232, 251, 255), (0, GROUND_Y), (W, GROUND_Y), 4)
    else:
        pygame.draw.rect(surface, (118, 172, 110), (0, GROUND_Y, W, H-GROUND_Y))
        pygame.draw.line(surface, (80, 130, 77), (0, GROUND_Y), (W, GROUND_Y), 4)
    txt(surface, 'PLACEHOLDER: ' + filename, 16, H-32, SMALL, (40, 76, 86))


def background(surface, filename, theme='park'):
    key = (filename, theme)
    if key not in images.background_cache:
        layer = pygame.Surface((W, H)).convert()
        _paint_background(layer, filename, theme)
        images.background_cache[key] = layer
    surface.blit(images.background_cache[key], (0, 0))


def frog_base(pose='rest', scale=1):
    """Return a cached transparent sprite, including when no PNG is supplied."""
    filename = {'rest':'frog_rest.png', 'jump':'frog_jump.png',
                'tumble':'frog_tumble.png', 'swim':'frog_swim.png',
                'dizzy':'frog_dizzy.png', 'crouch':'frog_crouch.png',
                'push_off':'frog_push_off.png', 'reach':'frog_reach.png', 'land':'frog_land.png'}.get(pose, 'frog_rest.png')
    size = (int(50*scale), int(42*scale))
    key = (pose, size)
    if key not in images.frog_bases:
        pic = None
        frame = int(pose[6:]) if pose.startswith('frame_') else (10 if pose == 'rest' else 6 if pose == 'jump' else None)
        if frame is not None:
            path = os.path.join(ASSET_DIR, f'frog_frame_{frame}.png')
            if os.path.isfile(path):
                source = pygame.image.load(path).convert_alpha()
                factor = 0.15 * scale
                pic = pygame.transform.smoothscale(source, (max(1, round(source.get_width()*factor)), max(1, round(source.get_height()*factor))))
        if pic is None:
            pic = images.load(filename, size)
        if pic is None and pose in ('crouch', 'push_off', 'reach', 'land'):
            pic = frog_base('jump' if pose in ('push_off', 'reach') else 'rest', scale)
        if pic is None:
            pic = pygame.Surface(size, pygame.SRCALPHA)
            sw, sh = size
            pygame.draw.ellipse(pic, (55, 172, 84), (3, sh//3, sw-6, sh//2))
            pygame.draw.circle(pic, (57, 181, 87), (int(sw*.75), int(sh*.35)), max(4, sw//5))
            pygame.draw.circle(pic, (255, 255, 255), (int(sw*.8), int(sh*.28)), max(2, sw//13))
            pygame.draw.circle(pic, (25, 39, 30), (int(sw*.83), int(sh*.28)), max(1, sw//24))
            if pose in ('jump', 'swim'):
                pygame.draw.line(pic, (25, 120, 59), (int(sw*.30), int(sh*.67)), (2, sh-2), 5)
            else:
                pygame.draw.line(pic, (25, 120, 59), (int(sw*.28), int(sh*.72)), (int(sw*.14), sh-3), 5)
        images.frog_bases[key] = pic
    return images.frog_bases[key]


def frog_render(pose='rest', angle=0, scale=1):
    """Rotated visual and collision mask are derived from the same cached pixels."""
    base = frog_base(pose, scale)
    degrees = int(round(angle/5)*5) % 360
    key = (pose, base.get_size(), degrees)
    if key not in images.frog_rotations:
        sprite = pygame.transform.rotate(base, degrees) if degrees else base
        images.frog_rotations[key] = (sprite, pygame.mask.from_surface(sprite))
    return images.frog_rotations[key]


def frog_sprite(surface, x, y, angle=0, pose='rest', scale=1):
    sprite, _ = frog_render(pose, angle, scale)
    surface.blit(sprite, sprite.get_rect(center=(round(x), round(y))))


def scene_actor(surface, filename, xy, size=(160, 175)):
    pic = images.load(filename, size)
    if pic:
        surface.blit(pic, pic.get_rect(center=(int(xy[0]), int(xy[1]))))
    else:
        r = pygame.Rect(0, 0, *size)
        r.center = (int(xy[0]), int(xy[1]))
        rounded(surface, r, (240, 200, 110), 15, INK)
        txt(surface, filename.replace('.png',''), r.centerx, r.centery, SMALL, INK, True)


def interpolate(p, q, t):
    return (p[0] + (q[0]-p[0])*t, p[1] + (q[1]-p[1])*t)


@dataclass
class Obstacle:
    spec: dict
    x: float
    y: float
    w: int
    h: int

    @classmethod
    def from_spec(cls, spec):
        return cls(spec, float(spec['x']), float(spec['bottom'] - spec['h']), int(spec['w']), int(spec['h']))

    @property
    def rect(self):
        return pygame.Rect(round(self.x), round(self.y), self.w, self.h)

    def update(self, dt):
        speed = self.spec.get('speed', 0)
        self.x += speed * dt
        if self.spec.get('wrap'):
            if speed < 0 and self.x + self.w < -20:
                self.x = W + 20
            elif speed > 0 and self.x > W + 20:
                self.x = -self.w - 20

    def draw(self, surface):
        pic = images.load(self.spec['image'], (self.w, self.h))
        if pic:
            surface.blit(pic, self.rect)
        else:
            c = (225, 112, 90) if self.spec.get('vehicle') else (143, 106, 77)
            rounded(surface, self.rect, c, min(12, self.h//4), INK)
            if self.spec.get('vehicle'):
                for offset in (25, self.w-25):
                    pygame.draw.circle(surface, (32, 41, 48), (int(self.x+offset), int(self.y+self.h)), 12)
            txt(surface, self.spec['name'].replace('_',' '), self.x+8, self.y+7, SMALL, (255,255,255))

    def collides(self, frog_rect, frog_mask):
        r = self.rect
        if not r.colliderect(frog_rect):
            return False
        if self.spec.get('collision') == 'rect':
            return True
        obstacle_mask = images.mask(self.spec['image'], (self.w, self.h))
        if obstacle_mask is None:
            # Placeholder geometry is rectangular; real PNGs use alpha masks.
            return True
        return obstacle_mask.overlap(frog_mask, (frog_rect.left-r.left, frog_rect.top-r.top)) is not None


# Maximum distance from the feet or visible body center to the launch branch.
LAUNCH_TOLERANCE_UNITS = 0.70

def launch_point(a, h, k, x, y, ground_y, body_offset):
    """Find a nearby point on the forward launch branch, in graph units.

    Sample at subpixel intervals horizontally and also check the exact
    surface intersection, which matters for very steep curves.
    """
    radius = LAUNCH_TOLERANCE_UNITS
    left, right = x-radius, min(x+radius, h-0.001)
    if right < left:
        return None
    count = max(1, math.ceil((right-left)*SCALE*4))
    candidates = [left+(right-left)*i/count for i in range(count+1)]
    for height in (y, ground_y, y+body_offset):
        root = right_intersection(a,h,k,height)
        if root is not None and left <= 2*h-root <= right:
            candidates.append(2*h-root)
    best = None
    for px in candidates:
        py = quadratic_y(a,h,k,px)
        # Do not align below the ground for a jump, or above the water for a dive.
        if (a < 0 and py < ground_y-1e-7) or (a > 0 and py > ground_y+1e-7):
            continue
        # Distance to the vertical segment from feet to body center.
        low, high = sorted((y,y+body_offset))
        dy = max(low-py, py-high, 0.0)
        distance = math.hypot(px-x,dy)
        if distance <= radius:
            # Prefer the feet when equally close to the body.
            score = distance + 0.15*math.hypot(px-x,py-y)
            if best is None or score < best[0]:
                best = (score,px,py)
    return None if best is None else best[1:]

HOLD_DELAY = 0.32
HOLD_INTERVAL = 0.05  # 20 adjustments per second after the delay

class InputBox:
    def __init__(self, x, y, label, value):
        self.rect = pygame.Rect(x, y, 49, 30)
        self.label = label
        self.value = value
        self.active = False

    def arrow_rects(self):
        return (pygame.Rect(self.rect.left, self.rect.bottom + 4, 26, 21),
                pygame.Rect(self.rect.right - 26, self.rect.bottom + 4, 26, 21))

    def draw(self, surface):
        rounded(surface, self.rect, (255,255,255), 6, BLUE if self.active else (154,170,181))
        txt(surface, self.value, self.rect.centerx, self.rect.centery, INPUT_FONT, INK, True)
        up, down = self.arrow_rects()
        for rect, glyph in ((up, '+'), (down, '-')):
            rounded(surface, rect, (218,232,244), 4, (117,145,171))
            txt(surface, glyph, rect.centerx, rect.centery, SMALL, INK, True)

    def step(self, direction):
        try:
            value = float(self.value)
        except ValueError:
            value = 0.0
        # Integer hundredths avoid accumulation artifacts such as 0.30000000004.
        value = (round(value * 100) + direction) / 100
        self.value = f'{value:.2f}'

    def key(self, event):
        if event.key == pygame.K_BACKSPACE:
            self.value = self.value[:-1]
        elif event.unicode in '0123456789.-' and len(self.value) < 10:
            self.value += event.unicode


from math import cos, pi, sin, tau
from pathlib import Path

import pygame

CAPTURE_ASSETS = Path(ASSET_DIR) / "capture"
GROUND = 477


def capture_ease(t):
    t = max(0.0, min(1.0, t))
    return t * t * (3 - 2 * t)


def capture_sprite(name, height):
    image = pygame.image.load(str(CAPTURE_ASSETS / name)).convert_alpha()
    image = image.subsurface(image.get_bounding_rect(min_alpha=100))
    width = round(height * image.get_width() / image.get_height())
    return pygame.transform.smoothscale(image, (width, height))


class CaptureScene:
    duration = 6.55

    def __init__(self, size):
        self.background = pygame.transform.smoothscale(
            pygame.image.load(str(CAPTURE_ASSETS / "park_pond.png")).convert(), size
        )
        self.boy = capture_sprite("boy.png", 332)
        self.frog = capture_sprite("frogo.png", 34)
        self.foreground = pygame.Surface(size, pygame.SRCALPHA)
        self.shadows = pygame.Surface(size, pygame.SRCALPHA)
        self.fade = pygame.Surface(size)

    def draw(self, screen, t):
        screen.blit(self.background, (0, 0))
        self.foreground.fill((0, 0, 0, 0))
        self.shadows.fill((0, 0, 0, 0))

        creep = capture_ease((t - 0.65) / 2.27)
        strike = capture_ease((t - 2.96) / 0.59)
        bob = 4 * abs(sin(tau * 2.1 * t)) * sin(pi * creep)
        bx = 1145 - 425 * creep - 15 * strike
        boy_rect = self.boy.get_rect(midbottom=(round(bx), round(GROUND - bob)))
        grip = pygame.Vector2(boy_rect.left + 14, boy_rect.top + 165)

        # Keep the opening down as the rim descends over the frog.
        hoop = grip + pygame.Vector2(-135 - 25 * strike, -19)
        hoop.y += (GROUND - hoop.y) * strike
        radius, rim_depth, dome_height = 55, 11, 67
        rim = pygame.Rect(0, 0, radius * 2, rim_depth * 2)
        rim.center = round(hoop.x), round(hoop.y)

        # Frogo makes a short hop and lands before the rim closes around him.
        hop = capture_ease((t - 2.72) / 0.76)
        # Keep the frog in place after contact, with a small startled recoil.
        fx = 513 - 65 * hop
        fy = GROUND - 25 * 4 * hop * (1 - hop)
        recoil = capture_ease((t - 3.55) / 0.21) - capture_ease((t - 3.77) / 0.36)
        fx -= 10 * recoil

        pygame.draw.ellipse(self.shadows, (31, 27, 22, 78),
                            (round(bx) - 102, GROUND - 5, 203, 19))
        pygame.draw.ellipse(self.shadows, (30, 25, 19, 82),
                            (round(fx) - 27, GROUND - 3, 54, 10))
        pygame.draw.ellipse(self.shadows, (38, 30, 22, round(85 * strike)),
                            (rim.left, GROUND - 7, rim.width, 18))
        screen.blit(self.shadows, (0, 0))

        # The mesh arches above the opening, leaving a pocket around Frogo.
        outline = [(hoop.x + radius * cos(a * pi / 24),
                    hoop.y - dome_height * sin(a * pi / 24))
                   for a in range(25)]
        pygame.draw.polygon(self.foreground, (49, 60, 43, 130), outline)
        screen.blit(self.foreground, (0, 0))
        self.foreground.fill((0, 0, 0, 0))

        near_edge = pygame.Vector2(rim.right, rim.centery)
        handle_end = grip + (grip - near_edge).normalize() * 48
        pygame.draw.line(screen, (65, 46, 32), near_edge, handle_end, 9)
        pygame.draw.line(screen, (139, 107, 70), near_edge, handle_end, 4)
        screen.blit(self.boy, boy_rect)
        screen.blit(self.frog, self.frog.get_rect(midbottom=(round(fx), round(fy))))

        # The near-side threads cross in front of Frogo only when enclosed.
        for column in range(-5, 6):
            u = column / 5
            points = [(hoop.x + u * radius * cos(angle),
                       hoop.y + rim_depth * (1 - u * u) * cos(angle)
                       - dome_height * sin(angle))
                      for angle in (step * pi / 24 for step in range(13))]
            pygame.draw.aalines(self.foreground, (226, 218, 177, 205), False, points)
        for row in range(1, 7):
            angle = row * pi / 16
            points = [(hoop.x + radius * u * cos(angle),
                       hoop.y + rim_depth * (1 - u * u) * cos(angle)
                       - dome_height * sin(angle))
                      for u in (column / 10 for column in range(-10, 11))]
            pygame.draw.aalines(self.foreground, (208, 199, 158, 180), False, points)
        pygame.draw.aalines(self.foreground, (157, 151, 116, 225), False, outline)
        pygame.draw.ellipse(self.foreground, (43, 47, 42, 255), rim, 5)
        pygame.draw.ellipse(self.foreground, (168, 162, 115, 255), rim.inflate(-3, -3), 2)
        screen.blit(self.foreground, (0, 0))

        darkness = max(1 - capture_ease(t / 0.65), capture_ease((t - 6.0) / 0.55))
        if darkness > 0:
            self.fade.set_alpha(round(255 * darkness))
            screen.blit(self.fade, (0, 0))


class Game:
    def __init__(self):
        self.running = True
        self.sequence_index = 0
        self.mode = 'sequence'
        self.menu = False
        self.message = ''
        self.message_until = 0
        self.grid_on = True
        self.grid_layer = None
        self.level = None
        self.obstacles = []
        self.frog_x = float(START_X)
        self.frog_y = float(GROUND_Y)
        self.jump_x_offset = 0.0
        self.jump_start = START_X
        self.jump_elapsed = 0
        self.landing_animation = 0.0
        self.crouch_remaining = 0.0
        self.jump_duration = 1
        self.jump_vx = 0.0  # Constant horizontal velocity in graph units per second.
        self.jump_end_x = START_X
        self.jump_ground_end_x = START_X
        self.jump_y_start = GROUND_Y
        self.parabola = None
        self.has_plotted = False
        self.curve_valid = False
        self.last_curve = None
        self.curve_until = 0
        self.jumping = False
        self.recovering = False
        self.recovery_elapsed = 0
        self.recovery_start = (0,0)
        self.recovery_target = (0,0)
        self.recovery_type = 'back'
        self.recovery_duration = 1
        self.recovery_side = 'back'
        self.landed_on = None
        self.launch_platform = None
        self.scene_elapsed = 0
        self.tornado_intro = None
        self.capture_scene = None
        self.capture_error = None
        self.tornado_error = None
        self.box_stage = 'intro'
        self.box_elapsed = 0.0
        self.box_attempt = 0
        self.box_questions = []
        self.box_q_index = 0
        self.box_correct = 0
        self.box_answer = ''
        self.box_feedback = ''
        self.box_feedback_until = 0
        self.box_last_score = 0
        self.box_open_fraction = 0
        self.box_escaped = False
        self.inputs = [InputBox(710, 96, 'a', '-0.25'), InputBox(809, 96, 'h', '-4.46'), InputBox(910, 96, 'k', '-2.00')]
        self.plot_btn = pygame.Rect(685, 163, 119, 32)
        self.jump_btn = pygame.Rect(815, 163, 112, 32)
        self.restart_btn = pygame.Rect(938, 163, 132, 32)
        self.menu_btn = pygame.Rect(1000, 10, 88, 33)
        self.next_btn = pygame.Rect(435, 555, 230, 48)
        self.held_adjustment = None  # (input index, direction, source)
        self.held_elapsed = 0.0
        self.held_repeats = 0
        self.round_total = sum(entry['type'] == 'level' and entry.get('id') != 'practice' for entry in GAME_SEQUENCE)
        self.round_number = 0
        self.advance()

    def notify(self, msg, seconds=3):
        self.message = msg
        self.message_until = pygame.time.get_ticks() + int(seconds*1000)

    def advance(self):
        self.sequence_index += 1 if self.mode != 'sequence' else 0
        if self.sequence_index >= len(GAME_SEQUENCE):
            self.mode = 'ending'
            return
        entry = GAME_SEQUENCE[self.sequence_index]
        self.mode = entry['type']
        self.menu = False
        if self.mode == 'level':
            self.round_number = sum(e['type'] == 'level' for e in GAME_SEQUENCE[:self.sequence_index+1])
            self.load_level(entry['id'])
        elif self.mode == 'scene':
            self.scene_elapsed = 0
            if entry.get('id') == 'child_capture':
                self.capture_scene = None
                self.capture_error = None
        elif self.mode == 'box':
            self.box_stage = 'intro'
            self.box_elapsed = 0.0
            self.box_last_score = 0
            self.box_questions = []
            self.box_attempt = 0
            self.box_open_fraction = 0
            self.box_escaped = False

    def load_level(self, level_id):
        self.level = LEVELS[level_id]
        self.grid_layer = None
        if level_id == 'practice':
            self.grid_on = True
        self.obstacles = [Obstacle.from_spec(spec) for spec in self.level['obstacles']]
        self.restart_level(notify=False)
        if self.level['mode'] == 'positive':
            self.set_default_equation(0.06, self.world_x(START_X + 240))
        else:
            self.set_default_equation(-0.14, self.world_x(START_X + 240))
        self.notify(self.level.get('intro', ''), 4)

    def set_default_equation(self, a, h):
        x, y = self.world_x(START_X), self.world_y(GROUND_Y)
        k = y - a*(x-h)**2
        for box, value in zip(self.inputs, (a, h, k)):
            box.value = f'{value:.2f}'

    def restart_level(self, notify=True):
        # Restart resets position and moving obstacles, but deliberately keeps input values.
        self.frog_x, self.frog_y = float(START_X), float(GROUND_Y)
        self.obstacles = [Obstacle.from_spec(spec) for spec in self.level['obstacles']]
        self.jumping = self.recovering = False
        self.landing_animation = self.crouch_remaining = 0.0
        self.landed_on = None
        self.launch_platform = None
        self.tire_passed = False
        self.parabola = None
        self.has_plotted = False
        self.curve_valid = False
        self.last_curve = None
        self.curve_until = 0
        if notify:
            self.notify('Round restarted. Adjust your quadratic and try again.')

    def world_x(self, px):
        return screen_to_world(px, ORIGIN_Y)[0]

    def world_y(self, py):
        return screen_to_world(ORIGIN_X, py)[1]

    def pixel_x(self, x):
        return world_to_screen(x, 0)[0]

    def pixel_y(self, y):
        return world_to_screen(0, y)[1]

    def equation_y(self, x):
        a, h, k = self.parabola
        return quadratic_y(a, h, k, x)

    def plot(self, silent=False):
        if self.jumping or self.recovering or self.landing_animation > 0:
            return
        self.curve_valid = False
        self.launch_plan = None
        def reject(reason):
            self.jump_reason = reason
            if not silent:
                self.notify(reason, 5)
        try:
            a, h, k = (float(box.value) for box in self.inputs)
        except ValueError:
            self.parabola = None
            return reject('Enter valid numbers for a, h and k.')
        if not all(math.isfinite(v) for v in (a,h,k)) or max(abs(h),abs(k)) > 10000 or not 0.001 <= abs(a) <= 100:
            self.parabola = None
            return reject('Use finite values and a nonzero a (magnitude 0.001 to 100).')
        self.parabola = (a,h,k)
        self.has_plotted = True
        self.last_curve = None
        allowed = self.level['mode']
        if self.level['theme'] == 'practice' and a > 0:
            return reject('Positive parabola plotted. Use negative a to jump upward.')
        if allowed == 'negative' and a > 0:
            return reject('Use a negative a for an upward jump.')
        if allowed == 'positive' and a < 0:
            return reject('Use a positive a for a downward dive.')
        x0, y0 = self.world_x(self.frog_x), self.world_y(self.frog_y)
        if h <= x0 - LAUNCH_TOLERANCE_UNITS:
            return reject('Move the vertex to the right of Frogo.')
        ground = self.world_y(GROUND_Y)
        # Match the frog's current height exactly; forgive horizontal error only.
        root = right_intersection(a,h,k,y0)
        sx = None if root is None else 2*h-root
        if sx is None or sx >= h:
            return reject('The launch branch must reach Frogo’s current height. Adjust k.')
        end = right_intersection(a,h,k,ground)
        offset = x0-sx
        # Diagnose range/height first when the curve is visibly near Frogo.
        nearby = launch_point(a,h,k,x0,y0,ground,15/SCALE) is not None
        if abs(offset) > LAUNCH_TOLERANCE_UNITS:
            if nearby and end is not None and self.pixel_x(end+offset) > W+240:
                return reject('This jump is too far. Choose a narrower parabola.')
            if nearby and not -60 <= self.pixel_y(k) <= H+60:
                return reject('The vertex is too far above or below the screen.')
            if nearby:
                return reject('Curve is near Frogo, but its launch at his feet is too far horizontally.')
            return reject('Bring the launch branch closer to Frogo at his current height.')
        if end is None or end <= sx + 0.03 or self.pixel_x(end+offset) <= self.frog_x + 1:
            return reject('The curve needs a landing point to the right of Frogo.')
        if self.level['theme'] == 'practice' and self.pixel_x(end+offset) > W-35:
            return reject('Choose a landing point inside the grid, or press R to restart.')
        if self.pixel_x(end+offset) > W+240:
            return reject('The landing is too far beyond the screen. Move the vertex left.')
        if not -60 <= self.pixel_y(k) <= H+60:
            return reject('The vertex is too far above or below the screen.')
        self.launch_plan = (sx, end, offset)
        self.curve_valid = True
        self.jump_reason = ''
        if not silent:
            self.notify('Curve plotted. Press J to follow it.', 2)

    def launch(self):
        if self.jumping or self.recovering or self.landing_animation > 0:
            self.notify('Wait until Frogo finishes moving.', 2)
            return
        if not self.has_plotted:
            self.notify('Press Enter to plot your quadratic first.')
            return
        # Revalidate current inputs and position, including after live edits.
        self.plot(silent=True)
        if not self.curve_valid:
            self.notify(self.jump_reason, 5)
            return
        a,h,k = self.parabola
        sx,end,self.jump_x_offset = self.launch_plan
        self.jump_start = self.frog_x
        self.jump_y_start = self.frog_y
        self.jump_ground_end_x = self.jump_end_x = self.pixel_x(end+self.jump_x_offset)
        self.jump_vx = horizontal_velocity(a, 9.8 if self.level['theme'] == 'water' else SIMULATED_GRAVITY)
        self.jump_duration = (end-sx)/self.jump_vx
        self.jump_elapsed = 0
        self.landing_animation = 0.0
        self.crouch_remaining = 0.0
        self.jumping = True
        self.crouch_remaining = 0.47 if self.level['theme'] != 'water' else 0.0
        self.launch_platform = self.landed_on
        self.landed_on = None

    def frog_visual(self):
        """One pose and angle for both drawing and collision detection."""
        if self.recovering:
            if self.recovery_type == 'tiny':
                return 'rest', 0
            direction = -1 if self.recovery_side == 'forward' else 1
            return 'tumble', direction*720*self.recovery_elapsed/self.recovery_duration
        if not self.jumping:
            if self.landing_animation > 0:
                return f'frame_{7 + min(3, int((0.32-self.landing_animation)/0.08))}', 0
            return 'rest', 0
        if self.crouch_remaining > 0:
            elapsed = 0.47-self.crouch_remaining
            frame = 1 + min(2, int(elapsed/0.11)) if elapsed < 0.33 else 4 + min(1, int((elapsed-0.33)/0.07))
            return f'frame_{frame}', 0
        a, h, _ = self.parabola
        vx = self.jump_vx
        vy = 2*a*(self.world_x(self.frog_x)-self.jump_x_offset-h)*vx
        angle = math.degrees(math.atan2(vy, vx))
        if self.level['theme'] == 'water':
            return 'swim', angle
        return 'frame_6', angle

    def frog_collision(self):
        pose, angle = self.frog_visual()
        sprite, mask = frog_render(pose, angle)
        if pose == 'rest' or (pose.startswith('frame_') and pose != 'frame_6'):
            rect = sprite.get_rect(midbottom=(round(self.frog_x), round(self.frog_y)))
        else:
            rect = sprite.get_rect(center=(round(self.frog_x), round(self.frog_y-15)))
        return rect, mask

    def frog_rect(self):
        return self.frog_collision()[0]

    def start_recovery(self, obstacle, vehicle=False, contact_x=None):
        self.jumping = False
        self.launch_platform = None
        self.recovering = True
        self.recovery_elapsed = 0
        self.recovery_start = (self.frog_x, self.frog_y)
        self.recovery_side = 'back'
        above_ground = max(0, GROUND_Y-self.frog_y)
        if vehicle:
            self.recovery_type = 'car'
            self.recovery_duration = 1.2
            target_x = self.jump_start
        else:
            # Collision side is determined by the frog's APPROACH and first contact,
            # not by whether its center crossed the obstacle midpoint.
            far = contact_x is not None and contact_x >= obstacle.rect.right - 14
            # A far-side collision is possible when the frog is descending past
            # the obstacle's right edge. Only allow forward recovery to safe ground.
            target_x = obstacle.rect.right + 35
            forward_safe = (far and target_x < EXIT_X and
                all(not other.rect.collidepoint(round(target_x), GROUND_Y-4)
                    for other in self.obstacles if other is not obstacle))
            if forward_safe:
                self.recovery_side = 'forward'
            else:
                target_x = max(self.jump_start, obstacle.rect.left - 35)
            if above_ground < 8:
                self.recovery_type = 'tiny'
                self.recovery_duration = .18
            elif above_ground < 65:
                self.recovery_type = 'low'
                self.recovery_duration = .45
            elif above_ground < 145:
                self.recovery_type = 'medium'
                self.recovery_duration = .70
            else:
                self.recovery_type = 'high'
                self.recovery_duration = .95
        self.recovery_target = (target_x, float(GROUND_Y))
        self.last_curve = self.parabola
        self.curve_until = pygame.time.get_ticks()+2400

    def can_land_on(self, ob, prev_feet, new_feet, old_x, new_x):
        if not ob.spec.get('landable') or ob.spec.get('vehicle'):
            return False
        if new_feet <= prev_feet:  # rising, never land
            return False
        top = ob.rect.top
        if prev_feet > top+2 or new_feet < top-2:
            return False
        # Feet cross top surface while horizontally over the safe portion.
        t = max(0., min(1., (top-prev_feet)/max(1e-6, new_feet-prev_feet)))
        x_at_top = old_x + (new_x-old_x)*t
        return ob.rect.left+12 <= x_at_top <= ob.rect.right-12

    def finish_landing(self, on_obstacle=None):
        self.jumping = False
        self.landing_animation = 0.32 if self.level['theme'] != 'water' else 0.0
        self.launch_platform = None
        self.landed_on = on_obstacle
        self.last_curve = self.parabola
        self.curve_until = pygame.time.get_ticks()+2400
        self.parabola = None
        self.has_plotted = False
        self.curve_valid = False
        if self.level['theme'] == 'practice':
            if self.frog_x >= EXIT_X:
                self.restart_level(notify=False)
                self.notify('Nice jump! Frogo is back at the start.')
            else:
                self.notify('Good landing! Plot another quadratic.')
            return
        if self.frog_x >= EXIT_X and self.level.get('tire_gate') and not self.tire_passed:
            self.restart_level(notify=False)
            self.notify('Pass through the tire before finishing the round.')
        elif self.frog_x >= EXIT_X and on_obstacle is None:
            self.notify('Round complete!', 1)
            self.mode = 'level_complete'
            self.complete_elapsed = 0
        elif on_obstacle is not None:
            self.notify('Landed on the obstacle! Plot a new quadratic.')
        elif any(0 <= ob.rect.left-self.frog_x < 80 for ob in self.obstacles):
            self.notify('Try another jump, or press R to restart.', 4)
        else:
            self.notify('Good landing! Plot another quadratic.')

    def update_level(self, dt):
        self.landing_animation = max(0.0, self.landing_animation-dt)
        for ob in self.obstacles:
            ob.update(dt)
        if self.recovering:
            self.recovery_elapsed += dt
            t = min(1., self.recovery_elapsed/self.recovery_duration)
            smooth = t*t*(3-2*t)
            self.frog_x = self.recovery_start[0]*(1-smooth)+self.recovery_target[0]*smooth
            lift = 0 if self.recovery_type == 'tiny' else (50 if self.recovery_type == 'car' else 18)
            self.frog_y = (self.recovery_start[1]*(1-smooth)+
                           self.recovery_target[1]*smooth-lift*math.sin(math.pi*t))
            if t >= 1:
                self.recovering = False
                self.parabola = None
                self.curve_valid = False
                self.notify('Adjust your equation or press R to restart.')
            return
        if not self.jumping:
            # Moving traffic can strike a stationary frog.
            if not self.recovering:
                fr, fm = self.frog_collision()
                for ob in self.obstacles:
                    if ob.spec.get('vehicle') and ob.collides(fr, fm):
                        self.start_recovery(ob, vehicle=True)
                        break
            return
        if self.crouch_remaining > 0:
            self.crouch_remaining = max(0.0, self.crouch_remaining-dt)
            return
        self.jump_elapsed += dt
        # Constant horizontal velocity; vertical velocity varies linearly
        # with time because y(x) is quadratic. No easing on the jump itself.
        t = min(1., self.jump_elapsed/self.jump_duration)
        new_x = min(self.jump_end_x,
                    self.jump_start + SCALE*self.jump_vx*self.jump_elapsed)
        # Substep in screen space, so fast jumps cannot tunnel through obstacles.
        segments = max(1, int(math.ceil(abs(new_x-self.frog_x)/3)))
        old_x = self.frog_x
        for step in range(1,segments+1):
            px0, py0 = self.frog_x, self.frog_y
            px1 = old_x+(new_x-old_x)*step/segments
            py1 = self.pixel_y(self.equation_y(self.world_x(px1)-self.jump_x_offset))
            self.frog_x, self.frog_y = px1, py1
            fr, fm = self.frog_collision()
            gate = self.level.get('tire_gate')
            if gate:
                crossing = tire_crossing(gate, px0, py0, px1, py1)
                if crossing is False:
                    contact = Obstacle({}, gate['x'], gate['top'], 1,
                                       gate['bottom']-gate['top'])
                    self.start_recovery(contact)
                    self.recovery_target = (self.jump_start, float(GROUND_Y))
                    self.notify('Aim through the middle of the tire opening.')
                    return
                if crossing is True:
                    self.tire_passed = True
            # Surface landing has priority over side/body collision.
            for ob in self.obstacles:
                if self.can_land_on(ob, py0, py1, px0, px1):
                    self.frog_y = float(ob.rect.top)
                    self.finish_landing(on_obstacle=ob)
                    return
            # Ground/surface interception (especially when jumping from a log).
            if self.level['mode'] != 'positive' and py0 < GROUND_Y-0.5 and py1 >= GROUND_Y:
                frac = (GROUND_Y-py0)/max(1e-6,py1-py0)
                self.frog_x = px0+(px1-px0)*max(0,min(1,frac))
                self.frog_y = float(GROUND_Y)
                self.finish_landing()
                return
            if self.level['mode'] == 'positive' and py0 > GROUND_Y+0.5 and py1 <= GROUND_Y:
                frac = (py0-GROUND_Y)/max(1e-6,py0-py1)
                self.frog_x = px0+(px1-px0)*max(0,min(1,frac))
                self.frog_y = float(GROUND_Y)
                self.finish_landing()
                return
            # Ignore residual sprite overlap with the launch platform only
            # during ascent. Landing and all other obstacles remain active.
            if self.launch_platform is not None and (
                    py1 > py0 or not fr.colliderect(self.launch_platform.rect)):
                self.launch_platform = None
            # Alpha masks follow the visible frog pixels.
            for ob in self.obstacles:
                # A landable platform is approached from above by the feet.
                # Do not treat its top as a side impact while the sprite's
                # lower limbs reach it slightly before the feet anchor.
                descending = py1 > py0
                top_approach = (ob.spec.get('landable') and descending and
                    py1 <= ob.rect.top + 2 and
                    ob.rect.left + 12 <= self.frog_x <= ob.rect.right - 12)
                if top_approach or ob is self.launch_platform:
                    continue
                if ob.collides(fr, fm):
                    # On the descending far edge, contact can be the obstacle's
                    # right side; a safe forward stumble is then permitted.
                    contact_x = fr.left if fr.left >= ob.rect.right-14 else fr.right
                    self.start_recovery(ob, vehicle=ob.spec.get('vehicle',False),
                                        contact_x=contact_x)
                    return
        if t >= 1:
            # Same-height root reached; do not snap to ground after an elevated
            # launch unless the frog actually intersects a surface.
            self.frog_y = self.pixel_y(self.equation_y(self.world_x(self.frog_x)-self.jump_x_offset))
            self.finish_landing()

    def edit_equation(self):
        # After the first Plot, every valid edit updates the preview and jump
        # eligibility together. Before first Plot, leave the graph blank.
        if self.has_plotted:
            self.plot(silent=True)
            self.message_until = 0
        else:
            self.curve_valid = False

    def adjust_input(self, index, direction):
        if self.mode != 'level' or self.jumping or self.recovering:
            return
        for i, box in enumerate(self.inputs):
            box.active = i == index
        self.inputs[index].step(direction)
        self.edit_equation()

    def begin_adjustment(self, index, direction, source):
        self.adjust_input(index, direction)
        self.held_adjustment = (index, direction, source)
        self.held_elapsed = 0.0
        self.held_repeats = 0

    def update_adjustment(self, dt):
        if not self.held_adjustment or self.mode != 'level':
            return
        index, direction, source = self.held_adjustment
        if source == 'mouse' and not pygame.mouse.get_pressed()[0]:
            self.held_adjustment = None
            return
        if source == 'keyboard':
            keys = pygame.key.get_pressed()
            if not keys[pygame.K_UP if direction > 0 else pygame.K_DOWN]:
                self.held_adjustment = None
                return
        self.held_elapsed += dt
        repeats = max(0, int((self.held_elapsed - HOLD_DELAY) / HOLD_INTERVAL) + 1)
        repeats = min(repeats, 12 + self.held_repeats)  # cap per-frame catch-up
        while self.held_repeats < repeats:
            self.adjust_input(index, direction)
            self.held_repeats += 1

    def update(self, dt):
        if self.menu:
            return
        self.update_adjustment(dt)
        if self.mode == 'scene':
            self.scene_elapsed += dt
            config = SCENES[GAME_SEQUENCE[self.sequence_index]['id']]
            duration = config['duration'] if 'duration' in config else sum(b['seconds'] for b in config['beats'])
            if self.scene_elapsed >= duration:
                if GAME_SEQUENCE[self.sequence_index].get('id') != 'child_capture' or self.capture_scene is not None:
                    self.advance()
                else:
                    self.scene_elapsed = 0.0
        elif self.mode == 'level':
            self.update_level(dt)
        elif self.mode == 'level_complete':
            self.landing_animation = max(0.0, self.landing_animation-dt)
            self.complete_elapsed += dt
            if self.complete_elapsed >= 1.0:
                self.advance()
        elif self.mode == 'box' and self.box_stage in ('intro', 'attempt', 'success'):
            self.box_elapsed += dt
            if self.box_stage == 'intro' and self.box_elapsed >= BEDROOM_ATTEMPTS * BEDROOM_CYCLE:
                self.box_stage = 'choice'
            elif self.box_stage == 'attempt' and self.box_elapsed >= 2 * BEDROOM_CYCLE:
                self.box_stage = 'success' if self.box_escaped else 'box_fail'
                self.box_elapsed = 0.0
            elif self.box_stage == 'success' and self.box_elapsed >= ESCAPE_DURATION:
                self.box_stage = 'escaped'
        elif self.mode == 'box' and self.box_stage == 'feedback':
            if pygame.time.get_ticks() >= self.box_feedback_until:
                self.box_q_index += 1
                if self.box_q_index >= len(self.box_questions):
                    self.box_last_score = self.box_correct
                    self.box_open_fraction = self.box_correct/max(1,len(self.box_questions))
                    self.try_box()
                else:
                    self.box_answer = ''
                    self.box_stage = 'question'

    def _make_grid(self):
        # Cached, full-screen grid with two-tone lines for varied backgrounds.
        layer = pygame.Surface((W, H), pygame.SRCALPHA)
        def line(start, end, axis=False):
            if self.level['theme'] == 'practice':
                pygame.draw.line(layer, (35, 45, 55) if axis else (215, 220, 225), start, end, 2 if axis else 1)
                return
            pygame.draw.line(layer, (12, 24, 34, 180 if axis else 120), start, end, 5 if axis else 3)
            pygame.draw.line(layer, (255, 255, 255, 245 if axis else 175), start, end, 2 if axis else 1)

        def label(value, x, y):
            if self.level['theme'] == 'practice':
                txt(layer, value, x, y, FONT, INK)
                return
            for dx, dy in ((-1,-1),(-1,1),(1,-1),(1,1),(-2,0),(2,0),(0,-2),(0,2)):
                txt(layer, value, x+dx, y+dy, FONT, (12, 24, 34))
            txt(layer, value, x, y, FONT, (255, 255, 255))

        for x in range(ORIGIN_X % SCALE, W, SCALE):
            line((x, 0), (x, H-1))
        for y in range(ORIGIN_Y % SCALE, H, SCALE):
            line((0, y), (W-1, y))
        line((0, ORIGIN_Y), (W-1, ORIGIN_Y), True)
        line((ORIGIN_X, 0), (ORIGIN_X, H-1), True)
        # One-unit grid squares; numbered ticks every five units.
        for n in range(-int(ORIGIN_X / SCALE), int((W-1-ORIGIN_X) / SCALE)+1):
            if n % 5 == 0:
                px = ORIGIN_X + n*SCALE
                line((px, ORIGIN_Y-5), (px, ORIGIN_Y+5), True)
                if n:
                    label(str(n), px+3, ORIGIN_Y+8)
        for n in range(-10, 11, 5):
            py = max(0, min(H-1, ORIGIN_Y-n*SCALE))
            line((ORIGIN_X-5, py), (ORIGIN_X+5, py), True)
            if n:
                label(str(n), ORIGIN_X+10, max(2, min(H-24, py-12)))
        label('0', ORIGIN_X+8, ORIGIN_Y+8)
        label('x', W-22, ORIGIN_Y-27)
        label('y', ORIGIN_X-24, 4)
        return layer

    def draw_grid(self, surface):
        if self.grid_layer is None:
            self.grid_layer = self._make_grid()
        surface.blit(self.grid_layer, (0, 0))

    def draw_curve(self, surface):
        curve = self.parabola
        if curve is None and self.last_curve and pygame.time.get_ticks() < self.curve_until:
            curve = self.last_curve
        if curve is None:
            return
        a, h, k = curve
        pts = []
        for px in range(0, W+1, 3):
            y = self.pixel_y(a*(self.world_x(px)-h)**2+k)
            if 0 <= y < H:
                pts.append((px, round(y)))
            elif len(pts) > 1:
                pygame.draw.lines(surface, (231, 78, 133), False, pts, 4)
                pts = []
            else:
                pts = []
        if len(pts) > 1:
            pygame.draw.lines(surface, (231, 78, 133), False, pts, 4)

    def draw_level(self, surface):
        theme = self.level['theme']
        if theme == 'practice':
            surface.fill((255, 255, 255))
        else:
            background(surface, self.level['background'], theme)
        if self.grid_on:
            self.draw_grid(surface)
        self.draw_curve(surface)
        for ob in self.obstacles:
            ob.draw(surface)
        pose, angle = self.frog_visual()
        sprite, _ = frog_render(pose, angle)
        frog_rect = self.frog_collision()[0]
        surface.blit(sprite, frog_rect)
        if self.level.get('tire_gate'):
            foreground = images.load('tire_foreground_right.png', (W, H))
            if foreground is not None:
                area = frog_rect.clip(surface.get_rect())
                surface.blit(foreground, area.topleft, area)
        # Compact equation editor in the upper-right corner. Keep the lower
        # screen unobstructed so the playfield fills the available height.
        rounded(surface, pygame.Rect(665, 5, 430, 200), (242, 247, 251), 12, (143, 166, 182))
        # Show round progress and the configured level title without crowding Menu.
        round_heading = f"Round {self.round_number} of {self.round_total} - {self.level['title']}"
        if theme == 'practice':
            round_heading = 'Free Practice'
        heading_font = SMALL if SMALL.size(round_heading)[0] <= 310 else INPUT_FONT
        txt(surface, round_heading, 675, 16, heading_font, BLUE)
        button(surface, self.menu_btn, 'MENU')
        # Three small centered numeric inputs appear IN the vertex-form equation.
        txt(surface, 'y =', 671, 94, MED)
        txt(surface, '(x −', 762, 94, MED)
        txt(surface, ')²', 862, 94, MED)
        txt(surface, '+', 893, 94, MED)
        for box in self.inputs:
            txt(surface, box.label, box.rect.centerx, 79, SMALL, BLUE, True)
            box.draw(surface)
        button(surface, self.plot_btn, 'Plot (Enter)')
        button(surface, self.jump_btn, 'Jump (J)')
        button(surface, self.restart_btn, 'Restart (R)')
        if self.parabola:
            a,h,k = self.parabola
            sign_h = '-' if h >= 0 else '+'
            sign_k = '+' if k >= 0 else '-'
            expression = f'y = {a:.2f}(x {sign_h} {abs(h):.2f})² {sign_k} {abs(k):.2f}'
            txt(surface, expression, 678, 49, SMALL, BLUE if self.curve_valid else INK)
        else:
            txt(surface, 'Enter plots; then arrows update live', 678, 49, SMALL)
        txt(surface, 'G: grid  |  Esc: menu', 20, H-27, SMALL)
        # The plotted line updates automatically after the first Plot.
        # A small marker shows the exact launch anchor (frog feet).
        if self.grid_on and not (self.level.get('tire_gate') and self.jumping):
            pygame.draw.circle(surface, (255, 245, 115), (round(self.frog_x), round(self.frog_y)), 5)
            pygame.draw.circle(surface, INK, (round(self.frog_x), round(self.frog_y)), 5, 1)
        if pygame.time.get_ticks() < self.message_until:
            # Put transient feedback in the center of the playfield, not over
            # the equation editor or the upper-right menu button.
            feedback_font = SMALL
            max_text_width = W - 130
            if feedback_font.size(self.message)[0] > max_text_width:
                feedback_font = INPUT_FONT
            message_width = min(W - 80, feedback_font.size(self.message)[0] + 38)
            feedback_rect = pygame.Rect(0, 0, message_width, 50)
            feedback_rect.center = (W // 2, H // 2)
            rounded(surface, feedback_rect, (255, 249, 219), 9, (186, 172, 126))
            txt(surface, self.message, W // 2, H // 2, feedback_font, INK, True)

    def draw_scene(self, surface):
        scene_id = GAME_SEQUENCE[self.sequence_index]['id']
        config = SCENES[scene_id]
        if scene_id == 'tornado_intro':
            if self.tornado_intro is None and self.tornado_error is None:
                try:
                    self.tornado_intro = TornadoIntro()
                except (OSError, pygame.error) as exc:
                    self.tornado_error = str(exc)
                    print('Tornado intro:', exc)
            if self.tornado_intro is not None:
                self.tornado_intro.draw(surface, self.scene_elapsed)
            else:
                background(surface, 'home_pond.png')
                txt(surface, 'Frogo was swept far from home by a tornado.', W//2, H//2, MED, INK, True)
                txt(surface, 'Intro artwork missing. Check assets/forest_pond.png and assets/tornado.png.', W//2, H//2+40, SMALL, INK, True)
            if self.scene_elapsed < SCENES['tornado_intro']['duration']:
                button(surface, pygame.Rect(W-145, H-67, 120, 40), 'Skip scene')
            return
        elapsed = self.scene_elapsed
        beat = config['beats'][-1]
        within = 0
        for candidate in config['beats']:
            if elapsed < candidate['seconds']:
                beat = candidate
                within = elapsed / candidate['seconds']
                break
            elapsed -= candidate['seconds']
        if beat.get('capture'):
            if self.capture_scene is None and self.capture_error is None:
                try:
                    self.capture_scene = CaptureScene((W, H))
                except (OSError, pygame.error, ValueError) as exc:
                    self.capture_error = str(exc)
                    print('Capture scene:', exc)
            if self.capture_scene is not None:
                self.capture_scene.draw(surface, elapsed)
            else:
                background(surface, 'playground_background.png')
                txt(surface, 'Capture artwork missing in assets/capture/', W//2, H//2, SMALL, INK, True)
                txt(surface, self.capture_error[:100], W//2, H//2+35, SMALL, INK, True)
            return
        background(surface, beat['background'])
        if 'actor' in beat:
            at = interpolate(beat['actor_at'], beat.get('actor_to',beat['actor_at']), within)
            scene_actor(surface, beat['actor'], at)
        if 'frog' in beat:
            at = interpolate(beat['frog'], beat.get('frog_to',beat['frog']), within)
            frog_sprite(surface, *at, angle=within*beat.get('spin',0), scale=1.3)
        scene_text(surface, config['title'], W//2, 75, MED)
        scene_text(surface, beat['caption'], W//2, 117)
        scene_text(surface, 'SPACE or click Skip to continue', W//2, H-42, SMALL)
        button(surface, pygame.Rect(W-145, H-67, 120, 40), 'Skip scene')

    def start_questions(self):
        self.box_attempt += 1
        self.box_questions = [dict(q) for q in random.sample(QUESTIONS, min(len(QUESTIONS), BOX_QUESTION_COUNT))]
        while len(self.box_questions) < BOX_QUESTION_COUNT:
            self.box_questions.append(dict(random.choice(QUESTIONS)))
        random.shuffle(self.box_questions)
        self.box_q_index = 0
        self.box_correct = 0
        self.box_answer = ''
        self.box_stage = 'question'

    def submit_answer(self):
        if self.box_stage != 'question':
            return
        q = self.box_questions[self.box_q_index]
        response = self.box_answer.strip().lower().replace(' ', '')
        answer = str(q['answer']).strip().lower().replace(' ', '')
        try:
            correct = response == answer or abs(float(response)-float(answer)) < 1e-6
        except ValueError:
            correct = response == answer
        if correct:
            self.box_correct += 1
            self.box_feedback = 'Correct! Frogo grows stronger.'
        else:
            self.box_feedback = 'Not quite. Hint: ' + q.get('hint','Try again next time.')
        self.box_stage = 'feedback'
        self.box_feedback_until = pygame.time.get_ticks()+2300

    def try_box(self):
        probability = BOX_ESCAPE_CHANCES.get(self.box_last_score, 0)
        self.box_escaped = self.box_last_score >= BOX_MIN_SCORE_TO_TRY and random.random() < probability
        self.box_elapsed = 0.0
        self.box_stage = 'attempt'

    def draw_box(self, surface):
        stage = self.box_stage
        pose = 'crouch'
        if stage in ('intro', 'attempt'):
            pose = bedroom_pose(self.box_elapsed, BEDROOM_POSES, loop=True)
        elif stage == 'success':
            pose = bedroom_pose(self.box_elapsed, ESCAPE_POSES)
        elif stage == 'escaped':
            pose = 'free'
        filename = f'frogo_{pose}.png'
        art = images.load(filename, (W, H))
        if art is not None:
            surface.blit(art, (0, 0))
        else:
            background(surface, 'child_room.png', 'city')
            txt(surface, f'Missing artwork: assets/{filename}', W//2, 35, SMALL, RED, True)
        if stage in ('question', 'feedback'):
            # Keep the upper part of the bedroom visible during the quiz.
            q = self.box_questions[self.box_q_index]
            scene_text(surface, f'Question {self.box_q_index+1} of {len(self.box_questions)}   |   Correct: {self.box_correct}', W//2, 369)
            scene_text(surface, q['prompt'], W//2, 410, SMALL)
            rounded(surface, pygame.Rect(280, 439, 360, 46), (255,255,255), 8, BLUE)
            txt(surface, self.box_answer, 295, 449, FONT)
            button(surface, pygame.Rect(655,440,150,44), 'Submit (Enter)')
            if stage == 'feedback':
                scene_text(surface, self.box_feedback[:90], W//2, 525, SMALL)
            return
        if stage == 'intro':
            scene_text(surface, 'Frogo tries to escape, but he is not strong enough.', W//2, 570, FONT)
        elif stage == 'choice':
            scene_text(surface, 'Answer 10 questions correctly to give Frogo the strength to escape!', W//2, 550, SMALL)
            button(surface, pygame.Rect(405, 582, 290, 48), 'Start challenge')
        elif stage == 'attempt':
            scene_text(surface, f'Score: {self.box_last_score}/10. Frogo tries to lift the lid again...', W//2, 570, FONT)
        elif stage == 'box_fail':
            scene_text(surface, f'Score: {self.box_last_score}/10. Frogo needs more strength. Try again!', W//2, 550, SMALL)
            button(surface, pygame.Rect(405, 582, 290, 48), 'Retry challenge')
        elif stage == 'success':
            scene_text(surface, 'Frogo is strong enough! The lid is opening!', W//2, 570, FONT)
        elif stage == 'escaped':
            if PART_ONE_ONLY:
                scene_text(surface, 'Congratulations! Frogo is free!', W//2, 542, MED)
                scene_text(surface, 'Be prepared to continue the adventure with Part 2 on Monday.', W//2, 566, SMALL)
                scene_text(surface, 'For now, feel free to practice graphing and jumping.', W//2, 586, SMALL)
                button(surface, pygame.Rect(405, 608, 290, 32), 'Free practice')
            else:
                scene_text(surface, 'Frogo is free!', W//2, 550, MED)
                button(surface, pygame.Rect(405, 582, 290, 48), 'Continue adventure')

    def draw_instructions(self, surface):
        background(surface, 'instructions_background.png')
        veil = pygame.Surface((W,H), pygame.SRCALPHA)
        veil.fill((10,24,36,205))
        surface.blit(veil,(0,0))
        scene_text(surface, 'HOW TO PLAY', W//2, 65, BIG)
        scene_text(surface, 'Help Frogo find his way home using quadratics.', W//2, 108, FONT)
        scene_text(surface, 'y = a(x - h)² + k', W//2, 165, BIG)
        scene_text(surface, 'a: width and direction     (h, k): vertex', W//2, 207, FONT)
        for i,(heading, detail) in enumerate((
            ('1.   CHOOSE', 'Enter a, h and k. Use negative a to jump upward.'),
            ('2.   PLOT', 'Press Enter. Adjust the pink curve until it passes near Frogo.'),
            ('3.   JUMP', 'Press J to follow the trajectory and clear the obstacles.'),
        )):
            y = 260+i*83
            txt(surface, heading, 190, y, MED, (139,225,183))
            txt(surface, detail, 190, y+34, FONT, (255,255,255))
        scene_text(surface, 'G: toggle grid     R: restart     Tab: change input     Esc: menu', W//2, 524, SMALL)
        button(surface, self.next_btn, 'Start adventure')

    def draw_ending(self, surface):
        background(surface, 'home_pond.png', 'forest')
        rounded(surface, pygame.Rect(180, 150, 740, 300), (245, 249, 250), 20)
        txt(surface, 'Great job!', W//2, 215, BIG, GREEN, True)
        txt(surface, 'You helped Frogo get safely home!', W//2, 284, MED, INK, True)
        frog_sprite(surface, W//2, 345, scale=1.6)
        button(surface, pygame.Rect(420, 465, 260, 48), 'Play again')

    def draw_menu(self, surface):
        veil = pygame.Surface((W,H), pygame.SRCALPHA)
        veil.fill((17, 28, 40, 175))
        surface.blit(veil, (0,0))
        rounded(surface, pygame.Rect(215, 68, 670, 525), (248,250,252), 18)
        txt(surface, 'Menu / Quick Reference', W//2, 110, MED, INK, True)
        for i, line in enumerate([
            'Vertex form: y = a(x - h)² + k',
            'a controls opening and width; (h, k) is the vertex.',
            'Enter: graph a quadratic. J: jump if it passes near Frogo.',
            'G: toggle the grid. R: restart round. Tab: change input box.',
            'Pink curve: planned jump. It remains visible during the jump.',
            f'Both axes: 1 unit = {SCALE} pixels. Origin (0, 0) is at center.',
            'If Frogo gets stuck near an obstacle, restart the round.',
        ]):
            txt(surface, line, 254, 143+i*27, SMALL, INK)
        if self.level and self.mode in ('level', 'level_complete'):
            # Position in the menu header's free upper-right space; right-aligned.
            coords = f'Frog: ({self.world_x(self.frog_x):.2f}, {self.world_y(self.frog_y):.2f})'
            rendered = INPUT_FONT.render(coords, True, BLUE)
            surface.blit(rendered, rendered.get_rect(topright=(868, 76)))
        button(surface, pygame.Rect(390, 340, 320, 54), 'Resume')
        button(surface, pygame.Rect(390, 405, 320, 54), 'Restart round')
        button(surface, pygame.Rect(390, 470, 320, 54), 'How to play')
        txt(surface, 'Esc to close menu', W//2, 556, SMALL, INK, True)

    def draw(self, surface):
        if self.mode in ('level','level_complete'):
            self.draw_level(surface)
        elif self.mode == 'scene':
            self.draw_scene(surface)
        elif self.mode == 'instructions':
            self.draw_instructions(surface)
        elif self.mode == 'box':
            self.draw_box(surface)
        else:
            self.draw_ending(surface)
        if self.menu:
            self.draw_menu(surface)

    def click(self, pos):
        x,y = pos
        if self.menu:
            if pygame.Rect(390,340,320,54).collidepoint(pos):
                self.menu = False
            elif pygame.Rect(390,405,320,54).collidepoint(pos):
                if self.mode in ('level', 'level_complete') and self.level:
                    self.restart_level()
                    self.mode = 'level'
                self.menu = False
            elif pygame.Rect(390,470,320,54).collidepoint(pos):
                self.menu = False
                self.return_mode = self.mode
                self.mode = 'instructions_overlay'
            return
        if self.mode == 'instructions_overlay':
            self.mode = self.return_mode
            return
        if self.mode == 'scene':
            if GAME_SEQUENCE[self.sequence_index].get('id') != 'child_capture' and pygame.Rect(W-145,H-67,120,40).collidepoint(pos):
                self.advance()
        elif self.mode == 'instructions':
            if self.next_btn.collidepoint(pos):
                self.advance()
        elif self.mode in ('level','level_complete'):
            if self.menu_btn.collidepoint(pos):
                self.menu = True
                return
            if self.mode == 'level_complete':
                return
            for i, b in enumerate(self.inputs):
                up, down = b.arrow_rects()
                if up.collidepoint(pos):
                    self.begin_adjustment(i, +1, 'mouse')
                    return
                if down.collidepoint(pos):
                    self.begin_adjustment(i, -1, 'mouse')
                    return
            for b in self.inputs:
                b.active = b.rect.collidepoint(pos)
            if self.plot_btn.collidepoint(pos):
                self.plot()
            elif self.jump_btn.collidepoint(pos):
                self.launch()
            elif self.restart_btn.collidepoint(pos):
                self.restart_level()
        elif self.mode == 'box':
            if self.box_stage in ('choice', 'box_fail') and pygame.Rect(405,582,290,48).collidepoint(pos):
                self.start_questions()
            elif self.box_stage == 'question' and pygame.Rect(655,440,150,44).collidepoint(pos):
                self.submit_answer()
            elif self.box_stage == 'escaped' and pygame.Rect(405,608 if PART_ONE_ONLY else 582,290,32 if PART_ONE_ONLY else 48).collidepoint(pos):
                self.advance()
        elif self.mode == 'ending' and pygame.Rect(420,465,260,48).collidepoint(pos):
            self.sequence_index = 0
            self.mode = 'sequence'
            self.advance()

    def key(self, event):
        # Development shortcut: preview the capture without completing rounds.
        if event.key in (pygame.K_F8, pygame.K_F9):
            self.sequence_index = next(i for i, entry in enumerate(GAME_SEQUENCE)
                                       if entry.get('id') == 'child_capture')
            self.mode = 'scene'
            self.menu = False
            self.scene_elapsed = 0.0
            self.capture_scene = None
            self.capture_error = None
            return
        if event.key == pygame.K_ESCAPE:
            if self.mode == 'instructions_overlay':
                self.mode = self.return_mode
            else:
                self.menu = not self.menu
            return
        if self.menu:
            return
        if self.mode == 'instructions_overlay':
            self.mode = self.return_mode
            return
        if self.mode == 'scene':
            if event.key == pygame.K_SPACE and GAME_SEQUENCE[self.sequence_index].get('id') != 'child_capture':
                self.advance()
        elif self.mode == 'instructions':
            if event.key in (pygame.K_RETURN, pygame.K_SPACE):
                self.advance()
        elif self.mode == 'level':
            if event.key == pygame.K_g:
                self.grid_on = not self.grid_on
            elif event.key == pygame.K_r:
                self.restart_level()
            elif event.key == pygame.K_TAB:
                active = next((i for i,b in enumerate(self.inputs) if b.active), -1)
                for b in self.inputs: b.active = False
                self.inputs[(active+1)%len(self.inputs)].active = True
            elif event.key in (pygame.K_UP, pygame.K_DOWN):
                selected = next((i for i,b in enumerate(self.inputs) if b.active), None)
                if selected is not None and not getattr(event, "repeat", False):
                    self.begin_adjustment(selected, +1 if event.key == pygame.K_UP else -1, 'keyboard')
            elif event.key == pygame.K_RETURN:
                self.plot()
            elif event.key == pygame.K_j:
                self.launch()
            else:
                for b in self.inputs:
                    if b.active:
                        b.key(event)
                        self.edit_equation()  # Keep old plot for comparison; replot to launch.
        elif self.mode == 'box' and self.box_stage == 'question':
            if event.key == pygame.K_RETURN:
                self.submit_answer()
            elif event.key == pygame.K_BACKSPACE:
                self.box_answer = self.box_answer[:-1]
            elif event.unicode.isprintable() and len(self.box_answer) < 45:
                self.box_answer += event.unicode
        elif self.mode == 'ending' and event.key == pygame.K_RETURN:
            self.sequence_index = 0
            self.mode = 'sequence'
            self.advance()


async def main():
    global screen
    game = Game()
    while game.running:
        real_dt = clock.tick(FPS)/1000.0
        dt = min(real_dt, .05)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                game.running = False
            elif event.type == pygame.VIDEORESIZE and sys.platform != 'emscripten':
                # Render internally at a fixed logical resolution, then scale.
                screen = pygame.display.set_mode(event.size, pygame.RESIZABLE)
            elif event.type == pygame.KEYDOWN:
                game.key(event)
            elif event.type == pygame.KEYUP:
                if game.held_adjustment and game.held_adjustment[2] == 'keyboard':
                    game.held_adjustment = None
            elif event.type == pygame.MOUSEBUTTONUP and event.button == 1:
                if game.held_adjustment and game.held_adjustment[2] == 'mouse':
                    game.held_adjustment = None
            elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                sx, sy = screen.get_size()
                scale = min(sx/W, sy/H)
                left, top = (sx-W*scale)/2, (sy-H*scale)/2
                if left <= event.pos[0] < left+W*scale and top <= event.pos[1] < top+H*scale:
                    game.click(((event.pos[0]-left)/scale, (event.pos[1]-top)/scale))
        game.update(real_dt if game.mode in ('scene', 'box') else dt)
        frame = pygame.Surface((W,H))
        if game.mode == 'instructions_overlay':
            game.draw_instructions(frame)
            txt(frame, 'Click or press Esc to return', W//2, 610, SMALL, BLUE, True)
        else:
            game.draw(frame)
        if screen.get_size() == (W,H):
            screen.blit(frame, (0,0))
        else:
            sw, sh = screen.get_size()
            scale = min(sw/W, sh/H)
            dw, dh = round(W*scale), round(H*scale)
            screen.fill((16, 25, 35))
            scaled = pygame.transform.scale(frame, (dw, dh))
            screen.blit(scaled, ((sw-dw)//2, (sh-dh)//2))
        pygame.display.flip()
        await asyncio.sleep(0)  # pygbag browser event-loop compatibility
    pygame.quit()


if __name__ == '__main__':
    asyncio.run(main())
